=== ecqlipse 2 (.ICO) by chrfb ===

The packet contains 131 system and 45 application icons for Windows XP in white respectively black colour.
The size of the icons is 48, 32 and 16 px.


Have fun

Christian

http://chrfb.deviantart.com

Munich, June 7th, 2008



